package br.com.isaconstance.bemi.navigation

import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import br.com.isaconstance.bemi.data.local.UserPreferences
import br.com.isaconstance.bemi.ui.screens.acesso.AcessoScreen
import br.com.isaconstance.bemi.ui.screens.conta.ContaScreen
import br.com.isaconstance.bemi.ui.screens.avisos.AvisosScreen
import br.com.isaconstance.bemi.ui.screens.cadastro.CadastroScreen
import br.com.isaconstance.bemi.ui.screens.cadastro.EstadoUsuario
import br.com.isaconstance.bemi.ui.screens.cadastro.UsuarioViewModel
import br.com.isaconstance.bemi.ui.screens.cadastro.UsuarioViewModelFactory
import br.com.isaconstance.bemi.ui.screens.consultas.ConsultasScreen
import br.com.isaconstance.bemi.ui.screens.documentos.DocumentosScreen
import br.com.isaconstance.bemi.ui.screens.emergencia.EmergenciaScreen
import br.com.isaconstance.bemi.ui.screens.emergencia.EmergenciaViewModel
import br.com.isaconstance.bemi.ui.screens.home.HomeScreen
import br.com.isaconstance.bemi.ui.screens.intro.IntroScreen
import br.com.isaconstance.bemi.ui.screens.login.LoginScreen
import br.com.isaconstance.bemi.ui.screens.splash.SplashScreen

@Composable
fun AppNavigation() {

    val navController = rememberNavController()
    val context = LocalContext.current
    val prefs = remember { UserPreferences(context) }
    val emergenciaViewModel: EmergenciaViewModel = viewModel(
        factory = object : androidx.lifecycle.ViewModelProvider.Factory {
            override fun <T : androidx.lifecycle.ViewModel> create(
                modelClass: Class<T>
            ): T {
                @Suppress("UNCHECKED_CAST")
                return EmergenciaViewModel(context.applicationContext) as T
            }
        }
    )
    val usuarioViewModel: UsuarioViewModel = viewModel(
        factory = UsuarioViewModelFactory(context.applicationContext)
    )

    val estadoUsuario by usuarioViewModel.estado.collectAsState()

    LaunchedEffect(estadoUsuario) {
        when (val estado = estadoUsuario) {

            is EstadoUsuario.Sucesso -> {
                Toast.makeText(
                    context,
                    "Bem-vindo(a), ${estado.nome}!",
                    Toast.LENGTH_SHORT
                ).show()

                navController.navigate(Routes.HOME) {
                    launchSingleTop = true
                }

                usuarioViewModel.limparEstado()
            }

            is EstadoUsuario.Erro -> {
                Toast.makeText(
                    context,
                    estado.mensagem,
                    Toast.LENGTH_LONG
                ).show()

                usuarioViewModel.limparEstado()
            }

            else -> Unit
        }
    }

    NavHost(
        navController = navController,
        startDestination = Routes.SPLASH
    ) {

        composable(Routes.SPLASH) {
            SplashScreen(
                onTimeout = {
                    val destino = if (prefs.introVista()) {
                        Routes.ACESSO
                    } else {
                        Routes.INTRO
                    }

                    navController.navigate(destino) {
                        popUpTo(Routes.SPLASH) {
                            inclusive = true
                        }
                    }
                }
            )
        }

        composable(Routes.INTRO) {
            IntroScreen(
                onFinish = {
                    prefs.marcarIntroVista()

                    navController.navigate(Routes.ACESSO) {
                        popUpTo(Routes.INTRO) {
                            inclusive = true
                        }
                    }
                }
            )
        }


        composable(Routes.ACESSO) {
            AcessoScreen(
                onEntrar = {
                    navController.navigate(Routes.LOGIN)
                },
                onCadastrar = {
                    navController.navigate(Routes.CADASTRO)
                },
                onContinuarVisitante = {
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.ACESSO) {
                            inclusive = true
                        }
                    }
                }
            )
        }

        composable(Routes.LOGIN) {
            LoginScreen(
                onVoltar = {
                    navController.popBackStack()
                },
                onEntrar = { email, senha ->
                    usuarioViewModel.entrar(email, senha)
                },
                onCadastrar = {
                    navController.navigate(Routes.CADASTRO)
                }
            )
        }

        composable(Routes.CADASTRO) {
            CadastroScreen(
                onVoltar = {
                    navController.popBackStack()
                },
                onCadastrar = { nome, email, senha ->
                    usuarioViewModel.cadastrar(nome, email, senha)
                },
                onIrLogin = {
                    navController.navigate(Routes.LOGIN)
                }
            )
        }


        composable(Routes.HOME) {
            HomeScreen(
                onAbrirDocumentos = {
                    navController.navigate(Routes.DOCUMENTOS)
                },
                onAbrirConsultas = {
                    navController.navigate(Routes.CONSULTAS)
                },
                onAbrirAvisos = {
                    navController.navigate(Routes.AVISOS)
                },
                onAbrirEmergencia = {
                    navController.navigate(Routes.EMERGENCIA)
                },
                onAbrirConta = {
                    navController.navigate(Routes.CONTA)
                }
            )
        }

        composable(Routes.CONSULTAS) {
            ConsultasScreen(
                onVoltarInicio = {
                    navController.popBackStack()
                }
            )
        }

        composable(Routes.DOCUMENTOS) {
            DocumentosScreen(
                onVoltarInicio = {
                    navController.popBackStack()
                }
            )
        }

        composable(Routes.AVISOS) {
            AvisosScreen(
                onVoltarInicio = {
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.HOME) {
                            inclusive = false
                        }
                        launchSingleTop = true
                    }
                }
            )
        }

        composable(Routes.EMERGENCIA) {
            EmergenciaScreen(
                viewModel = emergenciaViewModel,
                onVoltarInicio = {
                    navController.popBackStack()
                }
            )
        }

        composable(Routes.CONTA) {
            ContaScreen(
                onVoltarInicio = {
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.HOME) {
                            inclusive = false
                        }
                        launchSingleTop = true
                    }
                },
                onEntrar = {
                    navController.navigate(Routes.LOGIN)
                },
                onCadastrar = {
                    navController.navigate(Routes.CADASTRO)
                }
            )
        }
    }
}
